<?php
/**
 * Displays footer site info
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?>
<div class="site-info">
	<h5 style="text-align: center;">Made with <i class="fa fa-heart-o"></i> by <a href="http://countryfriedcoders.me" target="_blank">CountryFriedCoders</a></h5>
</div><!-- .site-info -->
